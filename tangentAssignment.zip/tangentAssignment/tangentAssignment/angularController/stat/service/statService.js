'use strict';

//debugger;

(function () {

    //debugger;

    var StatService = angular.module('myApp');
    StatService.factory('StatService', ['$rootScope', '$http', '$log', function ($rootScope, $http, $log) {
        debugger;



        return {
				

        };
    }]);
}());