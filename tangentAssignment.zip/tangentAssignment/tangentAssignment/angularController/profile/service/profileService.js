'use strict';

//debugger;

(function () {

    //debugger;

    var ProfileService = angular.module('myApp');
    ProfileService.factory('ProfileService', ['$rootScope', '$http', '$log', function ($rootScope, $http, $log) {

        debugger;
		




        return {
				

        };
    }]);
}());